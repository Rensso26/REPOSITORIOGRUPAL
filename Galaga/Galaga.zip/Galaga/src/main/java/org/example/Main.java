package org.example;

import View.BackGround;

public class
Main {
    public static void main(String[] args) {
        BackGround galaga = new BackGround(true);
    }
}
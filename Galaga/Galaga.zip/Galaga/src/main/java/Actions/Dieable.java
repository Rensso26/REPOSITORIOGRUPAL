package Actions;

public interface Dieable {
    public void die(int xbullet, int ybullet,int i);
}

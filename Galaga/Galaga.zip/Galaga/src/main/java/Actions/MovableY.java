package Actions;

public interface MovableY {
    public void moveUp(int distance);
    public void moveDown(int distance);
}

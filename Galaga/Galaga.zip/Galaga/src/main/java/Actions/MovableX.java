package Actions;

public interface MovableX {
    public void moveRigth(int distance);
    public void moveLeft(int distance);

}

package Actions;

public interface Contaible {

    public void plus(int i);

    public void minus(int i);
}
